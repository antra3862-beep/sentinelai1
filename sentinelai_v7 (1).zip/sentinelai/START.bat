@echo off
echo ============================================
echo   SentinelAI - Smart Surveillance System
echo ============================================
echo.

echo [1/3] Installing Python backend...
cd /d %~dp0backend
pip install -r requirements.txt --quiet
echo Done.
echo.

echo [2/3] Installing React frontend...
cd /d %~dp0frontend
call npm install --silent
echo Done.
echo.

echo [3/3] Starting SentinelAI...
echo Backend  --> http://localhost:8000
echo Frontend --> http://localhost:3000
echo.

start "SentinelAI Backend" cmd /k "cd /d %~dp0backend && python -m uvicorn main:app --reload --port 8000"
timeout /t 3 /nobreak >nul
start "SentinelAI Frontend" cmd /k "cd /d %~dp0frontend && npm start"

echo Open http://localhost:3000 in your browser.
pause
