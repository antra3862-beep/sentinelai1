"""
SentinelAI – FastAPI Backend
Serves all computer vision endpoints to the React frontend.
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from routers import detection, camera, enrol, alerts

app = FastAPI(title="SentinelAI API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://127.0.0.1:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(detection.router, prefix="/api/detection", tags=["Detection"])
app.include_router(camera.router,    prefix="/api/camera",    tags=["Camera"])
app.include_router(enrol.router,     prefix="/api/enrol",     tags=["Enrolment"])
app.include_router(alerts.router,    prefix="/api/alerts",    tags=["Alerts"])

@app.get("/")
def root():
    return {"status": "SentinelAI backend running", "version": "1.0.0"}

@app.get("/api/health")
def health():
    return {"status": "ok"}
