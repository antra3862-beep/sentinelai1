from fastapi import APIRouter
from services.vision_pipeline import get_pipeline

router = APIRouter()

@router.get("/")
def get_alerts():
    return get_pipeline().get_alerts()

@router.get("/stats")
def get_stats():
    s = get_pipeline().get_stats()
    return s

@router.get("/enrolled")
def get_enrolled():
    return {"enrolled": get_pipeline().get_enrolled()}

@router.delete("/clear")
def clear_alerts():
    get_pipeline()._alerts.clear()
    # reset live stats too
    p = get_pipeline()
    p._live_stats = {
        "persons_detected": 0,
        "known_count":      0,
        "unknown_count":    0,
        "objects_detected": 0,
        "alerts_total":     0,
        "known_log":        [],
        "unknown_log":      [],
    }
    p._seen_tracks.clear()
    return {"status": "cleared"}
