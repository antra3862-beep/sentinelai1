from fastapi import APIRouter
from fastapi.responses import JSONResponse
import cv2, time
from services.vision_pipeline import get_pipeline

router = APIRouter()

@router.get("/frame")
def get_frame(camera_id: int = 0, run_recognition: bool = False):
    # Try DirectShow first (Windows), then default
    for backend in [cv2.CAP_DSHOW, cv2.CAP_ANY]:
        cap = cv2.VideoCapture(camera_id, backend)
        if cap.isOpened():
            break

    if not cap.isOpened():
        return JSONResponse(
            {"error": f"Camera {camera_id} not found. Try a different index."},
            status_code=503
        )

    cap.set(cv2.CAP_PROP_FRAME_WIDTH,  640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
    cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)

    # Flush old frames from buffer
    for _ in range(3):
        cap.read()

    ret, frame = cap.read()
    cap.release()

    if not ret or frame is None:
        return JSONResponse(
            {"error": "Camera opened but could not read frame. Try resetting."},
            status_code=503
        )

    result = get_pipeline().process(frame, run_recognition=run_recognition)
    return result

@router.post("/reset-bg")
def reset_background():
    get_pipeline().reset_bg()
    return {"status": "background model reset"}

@router.get("/test")
def test_camera(camera_id: int = 0):
    for backend in [cv2.CAP_DSHOW, cv2.CAP_ANY]:
        cap = cv2.VideoCapture(camera_id, backend)
        if cap.isOpened():
            cap.release()
            return {"available": True, "camera_id": camera_id}
    return {"available": False, "camera_id": camera_id}
