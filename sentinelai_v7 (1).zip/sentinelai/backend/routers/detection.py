from fastapi import APIRouter, UploadFile, File
from fastapi.responses import JSONResponse
import numpy as np
import cv2
from services.vision_pipeline import get_pipeline

router = APIRouter()

@router.post("/image")
async def analyse_image(file: UploadFile = File(...)):
    data  = await file.read()
    arr   = np.frombuffer(data, np.uint8)
    frame = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    if frame is None:
        return JSONResponse({"error": "Could not decode image"}, status_code=400)
    pipeline = get_pipeline()
    result   = pipeline.process(frame, run_recognition=True)
    return result

@router.post("/video-frame")
async def analyse_frame(file: UploadFile = File(...)):
    data  = await file.read()
    arr   = np.frombuffer(data, np.uint8)
    frame = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    if frame is None:
        return JSONResponse({"error": "Could not decode frame"}, status_code=400)
    pipeline = get_pipeline()
    result   = pipeline.process(frame, run_recognition=False)
    return result
