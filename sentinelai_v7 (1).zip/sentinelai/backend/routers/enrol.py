from fastapi import APIRouter, UploadFile, File, Form
from fastapi.responses import JSONResponse
from pathlib import Path
import shutil, json

router = APIRouter()
ENROLLED_DIR = Path(__file__).parent.parent / "enrolled_faces"
ROLES_FILE   = ENROLLED_DIR / "roles.json"

def _load_roles():
    if ROLES_FILE.exists():
        with open(ROLES_FILE) as f: return json.load(f)
    return {}

def _save_roles(roles):
    ENROLLED_DIR.mkdir(exist_ok=True)
    with open(ROLES_FILE,"w") as f: json.dump(roles,f)

@router.post("/add")
async def enrol_person(
    name: str = Form(...),
    role: str = Form("Student"),
    file: UploadFile = File(...)
):
    ENROLLED_DIR.mkdir(exist_ok=True)
    dest = ENROLLED_DIR / f"{name}.jpg"
    with open(dest,"wb") as f: shutil.copyfileobj(file.file,f)
    roles = _load_roles()
    roles[name] = role
    _save_roles(roles)
    from services.vision_pipeline import get_pipeline
    get_pipeline().reload_faces()
    return {"status":"enrolled","name":name,"role":role}

@router.get("/list")
def list_enrolled():
    ENROLLED_DIR.mkdir(exist_ok=True)
    roles = _load_roles()
    names = [p.stem for p in list(ENROLLED_DIR.glob("*.jpg"))+list(ENROLLED_DIR.glob("*.png"))
             if p.stem != "roles"]
    return {"enrolled":[{"name":n,"role":roles.get(n,"Unknown")} for n in names]}

@router.delete("/{name}")
def remove_person(name: str):
    for ext in [".jpg",".png",".jpeg"]:
        p = ENROLLED_DIR / f"{name}{ext}"
        if p.exists(): p.unlink()
    roles = _load_roles()
    roles.pop(name, None)
    _save_roles(roles)
    from services.vision_pipeline import get_pipeline
    get_pipeline().reload_faces()
    return {"status":"removed","name":name}
