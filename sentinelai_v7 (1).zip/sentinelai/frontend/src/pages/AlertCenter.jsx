import React from 'react';
import { motion } from 'framer-motion';

const SEV_COLOUR = { HIGH:'#ef4444', MED:'#f59e0b', LOW:'#34d399' };
const TYPE_ICON  = {
  UNKNOWN_PERSON:'🚫', MOTION:'🌊',
  SECURITY_OBJECT:'📦', default:'⚠️',
};

export default function AlertCenter({ alerts = [] }) {
  const clear = () => fetch('/api/alerts/clear', {method:'DELETE'})
                        .then(()=>window.location.reload());

  return (
    <div>
      <div style={{display:'flex',justifyContent:'space-between',
                   alignItems:'flex-start',marginBottom:28}}>
        <div>
          <div style={{fontSize:'0.7rem',letterSpacing:'2px',color:'#334155',
                       fontWeight:700,marginBottom:8}}>ALERT MANAGEMENT</div>
          <h1 style={{fontSize:'2rem',fontWeight:900,
            background:'linear-gradient(135deg,#f87171,#f59e0b)',
            WebkitBackgroundClip:'text',WebkitTextFillColor:'transparent'}}>
            Alert Center
          </h1>
        </div>
        {alerts.length > 0 && (
          <button onClick={clear} style={{
            background:'rgba(239,68,68,0.1)',
            border:'1px solid rgba(239,68,68,0.3)',
            color:'#f87171',padding:'10px 18px',
            borderRadius:10,cursor:'pointer',
            fontWeight:600,fontSize:'0.82rem',
          }}>
            Clear All
          </button>
        )}
      </div>

      {/* Summary */}
      <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:12,marginBottom:24}}>
        {[
          ['🚫','Unknown Persons',alerts.filter(a=>a.type==='UNKNOWN_PERSON').length,'#ef4444'],
          ['🌊','Motion Events',  alerts.filter(a=>a.type==='MOTION').length,'#f59e0b'],
          ['📦','Security Objects',alerts.filter(a=>a.type==='SECURITY_OBJECT').length,'#c084fc'],
        ].map(([icon,k,v,c])=>(
          <div key={k} style={{
            background:'rgba(8,15,29,0.8)',border:`1px solid ${c}22`,
            borderTop:`3px solid ${c}`,borderRadius:14,padding:'20px 24px',
          }}>
            <div style={{fontSize:'1.5rem',marginBottom:6}}>{icon}</div>
            <div style={{fontSize:'1.8rem',fontWeight:800,color:c}}>{v}</div>
            <div style={{fontSize:'0.75rem',color:'#475569',marginTop:4}}>{k}</div>
          </div>
        ))}
      </div>

      {/* Alert list */}
      <div style={{background:'rgba(8,15,29,0.8)',
                   border:'1px solid rgba(30,58,95,0.4)',
                   borderRadius:16,padding:24}}>
        <div style={{fontSize:'0.65rem',letterSpacing:'2px',color:'#334155',
                     fontWeight:700,marginBottom:16}}>ALL ALERTS</div>
        {alerts.length === 0 ? (
          <div style={{textAlign:'center',color:'#1e3a5f',padding:40,fontSize:'0.85rem'}}>
            No alerts recorded
          </div>
        ) : (
          <div style={{display:'flex',flexDirection:'column',gap:8}}>
            {alerts.map((a,i)=>(
              <motion.div key={i}
                initial={{opacity:0,x:-10}} animate={{opacity:1,x:0}}
                transition={{delay:i*0.03}}
                style={{
                  display:'flex',alignItems:'center',gap:16,
                  padding:'14px 18px',borderRadius:12,
                  background:`${SEV_COLOUR[a.severity] ?? '#475569'}0a`,
                  border:`1px solid ${SEV_COLOUR[a.severity] ?? '#475569'}22`,
                }}
              >
                <div style={{fontSize:'1.2rem'}}>
                  {TYPE_ICON[a.type] ?? TYPE_ICON.default}
                </div>
                <div style={{flex:1}}>
                  <div style={{fontWeight:700,fontSize:'0.85rem',
                    color:SEV_COLOUR[a.severity]}}>{a.type.replace(/_/g,' ')}</div>
                  <div style={{fontSize:'0.78rem',color:'#64748b',marginTop:2}}>
                    {a.detail}
                  </div>
                </div>
                <div style={{textAlign:'right',flexShrink:0}}>
                  <div style={{
                    fontSize:'0.68rem',fontWeight:700,
                    color:SEV_COLOUR[a.severity],
                    background:`${SEV_COLOUR[a.severity]}15`,
                    padding:'3px 10px',borderRadius:6,marginBottom:4,
                  }}>{a.severity}</div>
                  <div style={{fontSize:'0.68rem',color:'#334155'}}>{a.time}</div>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
