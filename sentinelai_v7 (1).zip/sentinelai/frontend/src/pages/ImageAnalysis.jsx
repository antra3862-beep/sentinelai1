import React, { useState, useRef } from 'react';
import { motion } from 'framer-motion';

export default function ImageAnalysis() {
  const [result,   setResult]   = useState(null);
  const [loading,  setLoading]  = useState(false);
  const [preview,  setPreview]  = useState(null);
  const fileRef = useRef();

  const handleFile = async (file) => {
    if (!file) return;
    setPreview(URL.createObjectURL(file));
    setLoading(true); setResult(null);
    const fd = new FormData();
    fd.append('file', file);
    try {
      const res  = await fetch('/api/detection/image', {method:'POST',body:fd});
      const data = await res.json();
      setResult(data);
    } catch { alert('Backend error'); }
    setLoading(false);
  };

  const onDrop = (e) => {
    e.preventDefault();
    handleFile(e.dataTransfer.files[0]);
  };

  return (
    <div>
      <div style={{marginBottom:28}}>
        <div style={{fontSize:'0.7rem',letterSpacing:'2px',color:'#334155',
                     fontWeight:700,marginBottom:8}}>IMAGE ANALYSIS</div>
        <h1 style={{
          fontSize:'2rem',fontWeight:900,
          background:'linear-gradient(135deg,#818cf8,#c084fc)',
          WebkitBackgroundClip:'text',WebkitTextFillColor:'transparent',
        }}>Upload & Analyse</h1>
      </div>

      {/* Drop zone */}
      <div
        onDrop={onDrop}
        onDragOver={e=>e.preventDefault()}
        onClick={()=>fileRef.current.click()}
        style={{
          border:'2px dashed rgba(30,58,95,0.6)',
          borderRadius:16, padding:'40px',
          textAlign:'center', cursor:'pointer',
          background:'rgba(8,15,29,0.6)',
          marginBottom:24,
          transition:'border-color 0.3s',
        }}
      >
        <input ref={fileRef} type="file" accept="image/*" hidden
               onChange={e=>handleFile(e.target.files[0])}/>
        <div style={{fontSize:'2.5rem',marginBottom:10,opacity:0.4}}>🖼️</div>
        <div style={{color:'#334155',fontSize:'0.9rem'}}>
          Drop image here or <span style={{color:'#818cf8',fontWeight:600}}>browse</span>
        </div>
        <div style={{color:'#1e3a5f',fontSize:'0.75rem',marginTop:6}}>
          JPG · PNG · WebP
        </div>
      </div>

      {loading && (
        <div style={{textAlign:'center',color:'#818cf8',padding:40,fontSize:'0.9rem'}}>
          <div style={{fontSize:'2rem',marginBottom:12}}>⚙️</div>
          Running SentinelAI pipeline…
        </div>
      )}

      {result && (
        <motion.div initial={{opacity:0,y:16}} animate={{opacity:1,y:0}}>
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:20,marginBottom:20}}>
            {/* Original */}
            <div style={cardStyle}>
              <div style={labelStyle}>ORIGINAL</div>
              {preview && <img src={preview} alt="original"
                               style={{width:'100%',borderRadius:10}}/>}
            </div>
            {/* Processed */}
            <div style={cardStyle}>
              <div style={labelStyle}>PROCESSED OUTPUT</div>
              <img src={`data:image/jpeg;base64,${result.frame_b64}`}
                   alt="output" style={{width:'100%',borderRadius:10}}/>
            </div>
          </div>

          {/* Metrics */}
          <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:12,marginBottom:20}}>
            {[
              ['👥','Persons',    result.persons?.length ?? 0,   '#38bdf8'],
              ['✅','Known',      result.persons?.filter(p=>p.identity.status==='known').length??0,'#34d399'],
              ['⚠️','Unknown',    result.persons?.filter(p=>p.identity.status==='unknown').length??0,'#f87171'],
              ['⚡','Latency',    `${result.latency_ms}ms`, '#818cf8'],
            ].map(([icon,k,v,c])=>(
              <div key={k} style={{
                ...cardStyle, textAlign:'center', padding:'20px 16px',
                borderTop:`3px solid ${c}`,
              }}>
                <div style={{fontSize:'1.3rem',marginBottom:6}}>{icon}</div>
                <div style={{fontSize:'1.6rem',fontWeight:800,color:c}}>{v}</div>
                <div style={{fontSize:'0.72rem',color:'#475569',marginTop:4}}>{k}</div>
              </div>
            ))}
          </div>

          {/* Identity results */}
          {result.persons?.length > 0 && (
            <div style={cardStyle}>
              <div style={labelStyle}>IDENTITY VERIFICATION RESULTS</div>
              <div style={{display:'flex',flexDirection:'column',gap:10}}>
                {result.persons.map((p,i)=>(
                  <div key={i} style={{
                    display:'flex',alignItems:'center',gap:16,
                    padding:'12px 16px',borderRadius:10,
                    background: p.identity.status==='known'
                      ? 'rgba(52,211,153,0.08)':'rgba(239,68,68,0.08)',
                    border:`1px solid ${p.identity.status==='known'
                      ? 'rgba(52,211,153,0.25)':'rgba(239,68,68,0.25)'}`,
                  }}>
                    <div style={{
                      fontSize:'1.2rem',
                      background: p.identity.status==='known'
                        ? 'rgba(52,211,153,0.15)':'rgba(239,68,68,0.15)',
                      padding:'8px 12px',borderRadius:8,
                    }}>
                      {p.identity.status==='known'?'✅':'🚫'}
                    </div>
                    <div>
                      <div style={{fontWeight:700,
                        color:p.identity.status==='known'?'#34d399':'#f87171'}}>
                        {p.identity.name}
                      </div>
                      <div style={{fontSize:'0.75rem',color:'#475569'}}>
                        Track #{p.track_id} · Confidence: {(p.identity.confidence*100).toFixed(1)}%
                      </div>
                    </div>
                    <div style={{marginLeft:'auto',
                      fontSize:'0.75rem',fontWeight:700,
                      color:p.identity.status==='known'?'#34d399':'#f87171',
                      background:p.identity.status==='known'
                        ? 'rgba(52,211,153,0.1)':'rgba(239,68,68,0.1)',
                      padding:'4px 12px',borderRadius:6,
                    }}>
                      {p.identity.status==='known'?'AUTHORISED':'UNKNOWN'}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </motion.div>
      )}
    </div>
  );
}

const cardStyle = {
  background:'rgba(8,15,29,0.8)',
  border:'1px solid rgba(30,58,95,0.4)',
  borderRadius:14, padding:20,
};
const labelStyle = {
  fontSize:'0.65rem',letterSpacing:'2px',color:'#334155',
  fontWeight:700,marginBottom:14,
};
